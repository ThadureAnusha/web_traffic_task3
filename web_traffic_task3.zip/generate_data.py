"""
Generate synthetic web traffic dataset for analysis.
Run this first to create web_traffic_data.csv
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta

np.random.seed(42)
n = 5000

start_date = datetime(2024, 1, 1)
timestamps = [start_date + timedelta(
    days=np.random.randint(0, 180),
    hours=np.random.randint(0, 24),
    minutes=np.random.randint(0, 60)
) for _ in range(n)]

sources = np.random.choice(
    ['Organic Search', 'Direct', 'Social Media', 'Email', 'Paid Ads', 'Referral'],
    n, p=[0.38, 0.22, 0.18, 0.10, 0.08, 0.04]
)

devices = np.random.choice(['Mobile', 'Desktop', 'Tablet'], n, p=[0.54, 0.38, 0.08])

pages = ['Home', 'Products', 'Pricing', 'Blog', 'About', 'Contact', 'Signup', 'Login', 'Dashboard', 'Checkout']
landing_pages = np.random.choice(pages, n, p=[0.30, 0.20, 0.15, 0.12, 0.07, 0.05, 0.05, 0.03, 0.02, 0.01])

# Session duration depends on source and device
base_duration = np.where(sources == 'Email', 280,
                np.where(sources == 'Organic Search', 210,
                np.where(sources == 'Paid Ads', 160,
                np.where(sources == 'Direct', 240,
                np.where(sources == 'Social Media', 130, 180)))))

device_mult = np.where(devices == 'Desktop', 1.3, np.where(devices == 'Tablet', 1.1, 0.8))
session_duration = (base_duration * device_mult + np.random.normal(0, 60, n)).clip(10, 900).astype(int)

# Page views per session
page_views = np.where(session_duration > 300, np.random.randint(5, 12, n),
             np.where(session_duration > 150, np.random.randint(2, 6, n),
             np.random.randint(1, 3, n)))

# Bounce rate logic
bounce_prob = np.where(sources == 'Social Media', 0.65,
              np.where(sources == 'Paid Ads', 0.55,
              np.where(sources == 'Direct', 0.28,
              np.where(sources == 'Email', 0.22,
              np.where(sources == 'Organic Search', 0.38, 0.45)))))
bounced = np.random.binomial(1, bounce_prob, n)
page_views = np.where(bounced == 1, 1, page_views)
session_duration = np.where(bounced == 1, np.random.randint(5, 30, n), session_duration)

# Conversion (signup/purchase)
convert_prob = np.where(
    (sources == 'Email') & (bounced == 0), 0.18,
    np.where((sources == 'Paid Ads') & (bounced == 0), 0.12,
    np.where((sources == 'Organic Search') & (bounced == 0), 0.08,
    np.where((sources == 'Direct') & (bounced == 0), 0.10, 0.04))))
converted = np.random.binomial(1, convert_prob, n)
converted = np.where(bounced == 1, 0, converted)

countries = np.random.choice(
    ['United States', 'India', 'United Kingdom', 'Canada', 'Germany', 'Australia', 'Other'],
    n, p=[0.35, 0.18, 0.10, 0.08, 0.07, 0.05, 0.17]
)

df = pd.DataFrame({
    'session_id':       [f'S{str(i).zfill(5)}' for i in range(1, n+1)],
    'timestamp':        timestamps,
    'source':           sources,
    'device':           devices,
    'country':          countries,
    'landing_page':     landing_pages,
    'session_duration': session_duration,
    'page_views':       page_views,
    'bounced':          bounced,
    'converted':        converted,
})

df['timestamp'] = pd.to_datetime(df['timestamp'])
df = df.sort_values('timestamp').reset_index(drop=True)
df.to_csv('web_traffic_data.csv', index=False)

print(f"Dataset created: {len(df)} sessions")
print(f"  Bounce rate  : {df['bounced'].mean()*100:.1f}%")
print(f"  Conversion   : {df['converted'].mean()*100:.1f}%")
print(f"  Avg session  : {df['session_duration'].mean():.0f}s")
print(f"  Avg pages    : {df['page_views'].mean():.1f}")
