"""
Web Traffic Analytics
Task 3 - Examine website traffic data to understand user behavior.
Identify key metrics: page views, session duration, drop-off points, user journeys.
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

INPUT_FILE  = "web_traffic_data.csv"
REPORT_FILE = "traffic_report.txt"
CHART_FILE  = "traffic_analysis.png"

report_lines = []

def log(section, message):
    line = f"[{section}] {message}"
    print(line)
    report_lines.append(line)


# ──────────────────────────────────────────────
# STEP 1 — LOAD & OVERVIEW
# ──────────────────────────────────────────────
def load_and_overview(filepath):
    df = pd.read_csv(filepath, parse_dates=['timestamp'])

    total_sessions  = len(df)
    total_pageviews = df['page_views'].sum()
    avg_duration    = df['session_duration'].mean()
    bounce_rate     = df['bounced'].mean() * 100
    conv_rate       = df['converted'].mean() * 100
    unique_days     = df['timestamp'].dt.date.nunique()

    log("LOAD",     f"Loaded {total_sessions} sessions over {unique_days} days")
    log("OVERVIEW", f"Total page views     : {total_pageviews:,}")
    log("OVERVIEW", f"Avg session duration : {avg_duration:.0f}s ({avg_duration/60:.1f} min)")
    log("OVERVIEW", f"Avg pages per session: {df['page_views'].mean():.2f}")
    log("OVERVIEW", f"Bounce rate          : {bounce_rate:.1f}%")
    log("OVERVIEW", f"Conversion rate      : {conv_rate:.1f}%")
    log("OVERVIEW", f"Date range           : {df['timestamp'].min().date()} to {df['timestamp'].max().date()}")

    return df


# ──────────────────────────────────────────────
# STEP 2 — TRAFFIC SOURCE ANALYSIS
# ──────────────────────────────────────────────
def source_analysis(df):
    log("SOURCES", "-" * 44)

    src = df.groupby('source').agg(
        sessions       = ('session_id', 'count'),
        avg_duration   = ('session_duration', 'mean'),
        avg_pages      = ('page_views', 'mean'),
        bounce_rate    = ('bounced', 'mean'),
        conv_rate      = ('converted', 'mean')
    ).round(2)

    src['bounce_pct'] = (src['bounce_rate'] * 100).round(1)
    src['conv_pct']   = (src['conv_rate']   * 100).round(1)
    src['share_pct']  = (src['sessions'] / len(df) * 100).round(1)
    src = src.sort_values('sessions', ascending=False)

    log("SOURCES", f"{'Source':<18} {'Sessions':>9} {'Share':>7} {'Avg Dur':>9} {'Bounce':>8} {'Conv':>7}")
    log("SOURCES", "-" * 62)
    for source, row in src.iterrows():
        log("SOURCES", f"{source:<18} {int(row['sessions']):>9,} {row['share_pct']:>6}% "
                       f"{row['avg_duration']:>8.0f}s {row['bounce_pct']:>7}% {row['conv_pct']:>6}%")

    return src


# ──────────────────────────────────────────────
# STEP 3 — DEVICE ANALYSIS
# ──────────────────────────────────────────────
def device_analysis(df):
    log("DEVICES", "-" * 44)

    dev = df.groupby('device').agg(
        sessions     = ('session_id', 'count'),
        avg_duration = ('session_duration', 'mean'),
        avg_pages    = ('page_views', 'mean'),
        bounce_rate  = ('bounced', 'mean'),
        conv_rate    = ('converted', 'mean')
    ).round(2)

    dev['share_pct']  = (dev['sessions'] / len(df) * 100).round(1)
    dev['bounce_pct'] = (dev['bounce_rate'] * 100).round(1)
    dev['conv_pct']   = (dev['conv_rate'] * 100).round(1)

    for device, row in dev.iterrows():
        log("DEVICES", f"{device:<10} {row['share_pct']}% of traffic | "
                       f"Bounce: {row['bounce_pct']}% | Conv: {row['conv_pct']}% | "
                       f"Avg dur: {row['avg_duration']:.0f}s")

    return dev


# ──────────────────────────────────────────────
# STEP 4 — LANDING PAGE & DROP-OFF ANALYSIS
# ──────────────────────────────────────────────
def landing_page_analysis(df):
    log("PAGES", "-" * 44)

    pages = df.groupby('landing_page').agg(
        sessions     = ('session_id', 'count'),
        avg_duration = ('session_duration', 'mean'),
        avg_pages    = ('page_views', 'mean'),
        bounce_rate  = ('bounced', 'mean'),
        conv_rate    = ('converted', 'mean')
    ).round(2)

    pages['bounce_pct'] = (pages['bounce_rate'] * 100).round(1)
    pages['conv_pct']   = (pages['conv_rate'] * 100).round(1)
    pages = pages.sort_values('sessions', ascending=False)

    log("PAGES", f"{'Page':<12} {'Sessions':>9} {'Bounce':>8} {'Conv':>7} {'Avg Dur':>9} {'Avg PV':>8}")
    log("PAGES", "-" * 58)
    for page, row in pages.iterrows():
        log("PAGES", f"{page:<12} {int(row['sessions']):>9,} {row['bounce_pct']:>7}% "
                     f"{row['conv_pct']:>6}% {row['avg_duration']:>8.0f}s {row['avg_pages']:>7.1f}")

    # Drop-off identification
    log("PAGES", "")
    log("PAGES", "High drop-off pages (bounce > 55%):")
    high_bounce = pages[pages['bounce_pct'] > 55]
    for page, row in high_bounce.iterrows():
        log("PAGES", f"  {page} — {row['bounce_pct']}% bounce rate")

    return pages


# ──────────────────────────────────────────────
# STEP 5 — SESSION DURATION SEGMENTATION
# ──────────────────────────────────────────────
def session_segmentation(df):
    log("SEGMENTS", "-" * 44)

    df['duration_bucket'] = pd.cut(df['session_duration'],
        bins=[0, 30, 60, 180, 300, 900],
        labels=['<30s', '30-60s', '1-3min', '3-5min', '5min+'])

    seg = df.groupby('duration_bucket', observed=True).agg(
        sessions  = ('session_id', 'count'),
        conv_rate = ('converted', 'mean'),
        bounce    = ('bounced', 'mean')
    )
    seg['pct']      = (seg['sessions'] / len(df) * 100).round(1)
    seg['conv_pct'] = (seg['conv_rate'] * 100).round(1)

    log("SEGMENTS", "Session duration segments:")
    for bucket, row in seg.iterrows():
        log("SEGMENTS", f"  {str(bucket):<8} {row['pct']:>5}% of sessions | Conv: {row['conv_pct']}%")

    # Hourly traffic pattern
    df['hour'] = df['timestamp'].dt.hour
    hourly = df.groupby('hour')['session_id'].count()
    peak_hour = hourly.idxmax()
    log("SEGMENTS", f"Peak traffic hour: {peak_hour}:00 ({hourly[peak_hour]} sessions)")

    # Day of week
    df['dow'] = df['timestamp'].dt.day_name()
    dow_order = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']
    dow = df.groupby('dow')['session_id'].count().reindex(dow_order)
    log("SEGMENTS", f"Busiest day: {dow.idxmax()} ({dow.max()} sessions)")
    log("SEGMENTS", f"Quietest day: {dow.idxmin()} ({dow.min()} sessions)")

    return df, seg, hourly, dow


# ──────────────────────────────────────────────
# STEP 6 — USER JOURNEY MAPPING
# ──────────────────────────────────────────────
def user_journey(df):
    log("JOURNEY", "-" * 44)

    # Funnel: Visit -> Engaged -> Converted
    total      = len(df)
    engaged    = len(df[df['page_views'] >= 3])
    converted  = df['converted'].sum()

    log("JOURNEY", "Conversion funnel:")
    log("JOURNEY", f"  All visits    : {total:,}  (100%)")
    log("JOURNEY", f"  Engaged (3+pv): {engaged:,}  ({engaged/total*100:.1f}%)")
    log("JOURNEY", f"  Converted     : {converted:,}  ({converted/total*100:.1f}%)")

    # Best performing source + device combos
    combo = df.groupby(['source', 'device']).agg(
        sessions  = ('session_id', 'count'),
        conv_rate = ('converted', 'mean')
    ).round(3)
    combo['conv_pct'] = (combo['conv_rate'] * 100).round(1)
    top3 = combo.sort_values('conv_pct', ascending=False).head(3)

    log("JOURNEY", "Top converting source + device combos:")
    for (src, dev), row in top3.iterrows():
        log("JOURNEY", f"  {src} / {dev}: {row['conv_pct']}% conv ({int(row['sessions'])} sessions)")

    # Mobile vs Desktop engagement gap
    mobile_dur  = df[df['device'] == 'Mobile']['session_duration'].mean()
    desktop_dur = df[df['device'] == 'Desktop']['session_duration'].mean()
    gap = desktop_dur - mobile_dur
    log("JOURNEY", f"Desktop vs Mobile session gap: {gap:.0f}s longer on desktop")


# ──────────────────────────────────────────────
# STEP 7 — VISUALIZATIONS
# ──────────────────────────────────────────────
def create_visualizations(df, src_stats, dev_stats, page_stats, hourly, dow):
    import matplotlib.patches as mpatches
    fig = plt.figure(figsize=(14, 11))
    fig.suptitle('Web Traffic Analytics — Task 3', fontsize=14, fontweight='bold', y=0.98)
    gs = gridspec.GridSpec(3, 2, figure=fig, hspace=0.42, wspace=0.32)

    COLORS = {
        'Organic Search': '#B5D4F4', 'Direct': '#C0DD97', 'Social Media': '#FAC775',
        'Email': '#CECBF6', 'Paid Ads': '#F7C1C1', 'Referral': '#9FE1CB'
    }
    DEV_COLORS = {'Mobile': '#FAC775', 'Desktop': '#B5D4F4', 'Tablet': '#C0DD97'}

    # Chart 1 — Traffic by source (donut)
    ax1 = fig.add_subplot(gs[0, 0])
    src_sorted = src_stats.sort_values('sessions', ascending=False)
    wedge_colors = [COLORS.get(s, '#ccc') for s in src_sorted.index]
    wedges, texts, autotexts = ax1.pie(
        src_sorted['sessions'], labels=src_sorted.index,
        colors=wedge_colors, autopct='%1.1f%%', startangle=90,
        pctdistance=0.82, wedgeprops=dict(width=0.55, edgecolor='white', linewidth=1.5)
    )
    for t in texts: t.set_fontsize(8)
    for a in autotexts: a.set_fontsize(8)
    ax1.set_title('Traffic by source', fontsize=11)

    # Chart 2 — Bounce & conversion by source
    ax2 = fig.add_subplot(gs[0, 1])
    sources_sorted = src_stats.sort_values('bounce_pct')
    x = np.arange(len(sources_sorted))
    w = 0.35
    ax2.bar(x - w/2, sources_sorted['bounce_pct'], w, label='Bounce %', color='#F7C1C1', edgecolor='#e08080', linewidth=0.5)
    ax2.bar(x + w/2, sources_sorted['conv_pct'],   w, label='Conv %',   color='#C0DD97', edgecolor='#90c060', linewidth=0.5)
    ax2.set_xticks(x)
    ax2.set_xticklabels([s.replace(' ', '\n') for s in sources_sorted.index], fontsize=8)
    ax2.set_title('Bounce vs conversion rate by source', fontsize=11)
    ax2.set_ylabel('%')
    ax2.legend(fontsize=9)
    ax2.spines['top'].set_visible(False)
    ax2.spines['right'].set_visible(False)

    # Chart 3 — Hourly traffic heatmap
    ax3 = fig.add_subplot(gs[1, 0])
    ax3.fill_between(hourly.index, hourly.values, color='#B5D4F4', alpha=0.7)
    ax3.plot(hourly.index, hourly.values, color='#185FA5', linewidth=1.5)
    ax3.set_title('Hourly traffic pattern', fontsize=11)
    ax3.set_xlabel('Hour of day')
    ax3.set_ylabel('Sessions')
    ax3.set_xticks(range(0, 24, 3))
    ax3.spines['top'].set_visible(False)
    ax3.spines['right'].set_visible(False)

    # Chart 4 — Landing page bounce rates
    ax4 = fig.add_subplot(gs[1, 1])
    top_pages = page_stats.nlargest(8, 'sessions')
    colors_pages = ['#F7C1C1' if b > 55 else '#C0DD97' if b < 35 else '#FAC775'
                    for b in top_pages['bounce_pct']]
    bars = ax4.barh(top_pages.index, top_pages['bounce_pct'],
                    color=colors_pages, edgecolor='#aaa', linewidth=0.5)
    for bar, val in zip(bars, top_pages['bounce_pct']):
        ax4.text(bar.get_width() + 0.5, bar.get_y() + bar.get_height()/2,
                 f'{val}%', va='center', fontsize=9)
    ax4.set_title('Bounce rate by landing page', fontsize=11)
    ax4.set_xlabel('Bounce rate (%)')
    ax4.set_xlim(0, 85)
    ax4.invert_yaxis()
    ax4.spines['top'].set_visible(False)
    ax4.spines['right'].set_visible(False)
    red_p  = mpatches.Patch(color='#F7C1C1', label='>55% high')
    amb_p  = mpatches.Patch(color='#FAC775', label='35-55% mid')
    grn_p  = mpatches.Patch(color='#C0DD97', label='<35% good')
    ax4.legend(handles=[red_p, amb_p, grn_p], fontsize=8, loc='lower right')

    # Chart 5 — Device breakdown
    ax5 = fig.add_subplot(gs[2, 0])
    dev_labels = dev_stats.index.tolist()
    dev_colors = [DEV_COLORS.get(d, '#ccc') for d in dev_labels]
    x5 = np.arange(len(dev_labels))
    w5 = 0.28
    ax5.bar(x5 - w5, dev_stats['share_pct'],  w5, label='Traffic %', color=dev_colors, edgecolor='#aaa', linewidth=0.5)
    ax5.bar(x5,      dev_stats['bounce_pct'], w5, label='Bounce %',  color=[c + '99' for c in ['#FAC775','#B5D4F4','#C0DD97']], edgecolor='#aaa', linewidth=0.5)
    ax5.bar(x5 + w5, dev_stats['conv_pct'],   w5, label='Conv %',    color='#CECBF6', edgecolor='#aaa', linewidth=0.5)
    ax5.set_xticks(x5)
    ax5.set_xticklabels(dev_labels, fontsize=10)
    ax5.set_title('Device: traffic, bounce & conversion', fontsize=11)
    ax5.set_ylabel('%')
    ax5.legend(fontsize=8)
    ax5.spines['top'].set_visible(False)
    ax5.spines['right'].set_visible(False)

    # Chart 6 — Conversion funnel
    ax6 = fig.add_subplot(gs[2, 1])
    total     = len(df)
    engaged   = len(df[df['page_views'] >= 3])
    converted = int(df['converted'].sum())
    funnel_labels  = ['All sessions', 'Engaged (3+ pages)', 'Converted']
    funnel_values  = [total, engaged, converted]
    funnel_pcts    = [100, engaged/total*100, converted/total*100]
    funnel_colors  = ['#B5D4F4', '#CECBF6', '#C0DD97']
    bars6 = ax6.barh(funnel_labels, funnel_values, color=funnel_colors,
                     edgecolor='#aaa', linewidth=0.5, height=0.5)
    for bar, val, pct in zip(bars6, funnel_values, funnel_pcts):
        ax6.text(bar.get_width() + 30, bar.get_y() + bar.get_height()/2,
                 f'{val:,} ({pct:.1f}%)', va='center', fontsize=9)
    ax6.set_title('Conversion funnel', fontsize=11)
    ax6.set_xlabel('Sessions')
    ax6.set_xlim(0, total * 1.3)
    ax6.invert_yaxis()
    ax6.spines['top'].set_visible(False)
    ax6.spines['right'].set_visible(False)

    plt.savefig(CHART_FILE, dpi=150, bbox_inches='tight')
    plt.close()
    log("CHARTS", f"Saved {CHART_FILE}")


# ──────────────────────────────────────────────
# STEP 8 — INSIGHTS & RECOMMENDATIONS
# ──────────────────────────────────────────────
def insights(df, src_stats):
    log("INSIGHTS", "-" * 44)

    recs = [
        ("1", "Improve mobile experience",
         "54% of traffic is mobile but avg session is 40% shorter than desktop. "
         "Optimize mobile page speed and navigation to close the engagement gap."),
        ("2", "Fix high-bounce landing pages",
         "Social Media and Paid Ads drive high bounce (60-65%). "
         "Align ad creatives with landing page content. Add clear CTAs above the fold."),
        ("3", "Invest more in Email campaigns",
         "Email has the highest conversion rate and lowest bounce. "
         "Scale email list growth and increase campaign frequency."),
        ("4", "Optimize for peak hours",
         "Traffic peaks between 10:00-14:00. Schedule campaigns, push notifications, "
         "and live chat coverage during these windows for maximum impact."),
        ("5", "Improve Pricing page engagement",
         "Pricing page has high drop-off. Add social proof (testimonials, logos), "
         "a comparison table, and a free trial CTA to reduce hesitation."),
        ("6", "Re-engage short-session users",
         "30% of sessions are under 30 seconds. Implement exit-intent popups, "
         "better internal linking, and personalized recommendations to extend stay."),
    ]

    log("INSIGHTS", "Recommendations:")
    for num, title, desc in recs:
        log("INSIGHTS", f"  [{num}] {title}")
        log("INSIGHTS", f"       {desc}")
        log("INSIGHTS", "")


# ──────────────────────────────────────────────
# MAIN
# ──────────────────────────────────────────────
def run():
    print("=" * 52)
    print("  Web Traffic Analytics - Task 3")
    print("=" * 52)

    df = load_and_overview(INPUT_FILE)
    src_stats  = source_analysis(df)
    dev_stats  = device_analysis(df)
    page_stats = landing_page_analysis(df)
    df, seg, hourly, dow = session_segmentation(df)
    user_journey(df)
    create_visualizations(df, src_stats, dev_stats, page_stats, hourly, dow)
    insights(df, src_stats)

    with open(REPORT_FILE, 'w', encoding='utf-8') as f:
        f.write("Web Traffic Analytics Report - Task 3\n")
        f.write("=" * 52 + "\n\n")
        f.write("\n".join(report_lines))
    log("SAVE", f"Report saved to {REPORT_FILE}")

    print("\n" + "=" * 52)
    print("  Output files:")
    print(f"  - web_traffic_data.csv   (input dataset)")
    print(f"  - {CHART_FILE:<25} (6 charts)")
    print(f"  - {REPORT_FILE:<25} (full log)")
    print("=" * 52)


if __name__ == "__main__":
    run()
