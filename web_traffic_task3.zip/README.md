# Web Traffic Analytics — Task 3

Examine website traffic data to understand user behavior.
Identify key metrics: page views, session duration, drop-off points, user journeys.

## Files

```
task3/
├── generate_data.py     <- Step 1: create the dataset
├── traffic_analysis.py  <- Step 2: run full analysis
├── requirements.txt
└── README.md
```

After running, these are generated:
- `web_traffic_data.csv`   — 5000 session records
- `traffic_analysis.png`   — 6 visualisation charts
- `traffic_report.txt`     — full analysis log

## Setup & Run

```bash
pip install -r requirements.txt
python generate_data.py
python traffic_analysis.py
```

## What it does

| Step | Analysis |
|------|----------|
| 1 | Load & overview — sessions, bounce rate, conversion rate |
| 2 | Traffic source analysis — sessions, bounce %, conv % per source |
| 3 | Device analysis — Mobile vs Desktop vs Tablet breakdown |
| 4 | Landing page & drop-off — high-bounce page identification |
| 5 | Session segmentation — duration buckets + hourly/daily patterns |
| 6 | User journey mapping — funnel + top converting combos |
| 7 | Visualizations — 6 charts saved as PNG |
| 8 | Insights & recommendations — 6 actionable improvements |
